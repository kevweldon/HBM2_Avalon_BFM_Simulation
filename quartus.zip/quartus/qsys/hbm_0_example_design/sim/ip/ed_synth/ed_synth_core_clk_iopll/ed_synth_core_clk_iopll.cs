# system info ed_synth_core_clk_iopll on 2023.05.03.11:32:00
system_info:
name,value
DEVICE,1SM21CHU2F53E2VG
DEVICE_FAMILY,Stratix 10
GENERATION_ID,0
#
#
# Files generated for ed_synth_core_clk_iopll on 2023.05.03.11:32:00
files:
filepath,kind,attributes,module,is_top
sim/ed_synth_core_clk_iopll.v,VERILOG,CONTAINS_INLINE_CONFIGURATION,ed_synth_core_clk_iopll,true
altera_iopll_1931/sim/ed_synth_core_clk_iopll_altera_iopll_1931_mkn2j5a.vo,VERILOG,,ed_synth_core_clk_iopll_altera_iopll_1931_mkn2j5a,false
altera_iopll_1931/sim/stratix10_altera_iopll.v,VERILOG,,ed_synth_core_clk_iopll_altera_iopll_1931_mkn2j5a,false
#
# Map from instance-path to kind of module
instances:
instancePath,module
ed_synth_core_clk_iopll.core_clk_iopll,ed_synth_core_clk_iopll_altera_iopll_1931_mkn2j5a
